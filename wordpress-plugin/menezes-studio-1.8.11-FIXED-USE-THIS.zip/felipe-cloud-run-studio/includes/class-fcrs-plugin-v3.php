<?php

defined('ABSPATH') || exit;

class FCRS_Plugin {
  const GENERATE_ACTION = 'fcrs_generate_image';
  const JOB_STATUS_ACTION = 'fcrs_job_status';
  const SAVE_SETTINGS_ACTION = 'fcrs_save_settings';
  const SAVE_TEMPLATE_ACTION = 'fcrs_save_template';
  const DELETE_TEMPLATE_ACTION = 'fcrs_delete_template';
  const NONCE = 'fcrs_generate_nonce';
  const STATUS_NONCE = 'fcrs_job_status_nonce';
  const SETTINGS_NONCE = 'fcrs_save_settings_nonce';
  const TEMPLATE_NONCE = 'fcrs_save_template_nonce';
  const DELETE_TEMPLATE_NONCE = 'fcrs_delete_template_nonce';
  const META_NONCE = 'fcrs_article_meta_nonce';
  const SHORTCODE = 'felipe_cloud_run_studio';
  const RESULT_PREFIX = 'fcrs_result_';
  const PAGE_SLUG = 'felipe-cloud-run-studio';
  const OPTION_KEY = 'fcrs_settings';
  const TEMPLATES_OPTION_KEY = 'fcrs_templates';
  const POST_META_TEMPLATE = '_fcrs_template_key';
  const POST_META_MODEL = '_fcrs_model_override';
  const POST_META_ENABLED = '_fcrs_enabled';
  const DEFAULT_IMAGE_FORMAT = 'image/png';
  const DEFAULT_IMAGE_SIZE = '1K';
  const DEFAULT_ASPECT_RATIO = '1:1';
  const DEFAULT_JPEG_QUALITY = 75;
  const DEFAULT_PROCESS_TYPE = '1';
  const RESULT_TTL = 7200;
  const MAX_REFERENCE_IMAGES = 7;
  const MAX_REFERENCE_IMAGE_DIMENSION = 1400;
  const MAX_REFERENCE_IMAGE_BYTES = 700000;
  const MAX_REFERENCE_PAYLOAD_BYTES = 5000000;

  /**
   * @var FCRS_Plugin|null
   */
  private static $instance = null;

  /**
   * @return array<string, string>
   */
  private function get_template_languages() {
    return array(
      'pt_BR' => 'Português (Brasil)',
      'es_ES' => 'Español',
      'en_US' => 'English',
    );
  }

  /**
   * @param string $language
   * @return string
   */
  private function normalize_interface_language($language) {
    $language = (string) $language;
    $languages = $this->get_template_languages();

    return isset($languages[$language]) ? $language : 'pt_BR';
  }

  /**
   * @param string $language
   * @return array<string, mixed>
   */
  private function get_interface_strings($language) {
    $language = $this->normalize_interface_language($language);

    if ('es_ES' === $language) {
      return array(
        'tip' => 'Consejo: usa fotos nítidas, con buena iluminación y poco filtro. Si hay rostro, intenta enviar imágenes donde aparezca bien.',
        'loading_title' => 'Generando tu imagen',
        'loading_messages' => array(
          'Estamos generando tu imagen con mucho cuidado.',
          'Organizando luz, encuadre y detalles finales.',
          'Eligiendo los mejores detalles para que todo se vea aún mejor.',
          'Preparando un resultado bonito para mostrarte aquí.',
          'Ajustando colores, contraste y expresión con bastante cuidado.',
          'Casi listo: tu imagen está recibiendo los últimos retoques.',
          'Dando un toque especial para que tu imagen se vea aún más increíble.',
          'Refinando cada detalle para entregarte un resultado muy bonito.',
        ),
        'waiting_message' => 'Tu pedido fue enviado. Espera solo un poco más.',
        'poll_failed_message' => 'No se pudo consultar el progreso del proceso.',
        'query_failed_message' => 'No se pudo consultar el proceso.',
        'temporary_result' => 'Resultado temporal',
        'until' => 'hasta',
        'media_library' => 'Biblioteca multimedia',
        'download_label' => 'Descargar imagen',
        'upload_label' => 'Sube tus fotos',
        'upload_required' => 'Esta plantilla requiere al menos una foto.',
        'upload_optional' => 'La foto es opcional para esta plantilla.',
        'upload_subhint' => 'Puedes enviar hasta %d imágenes.',
        'selected_photos' => 'Fotos seleccionadas',
        'result_image_label' => 'Imagen generada',
      );
    }

    if ('en_US' === $language) {
      return array(
        'tip' => 'Tip: use sharp photos, with good lighting and light filtering. If there is a face, try to send images where it appears clearly.',
        'loading_title' => 'Generating your image',
        'loading_messages' => array(
          'We are generating your image with great care.',
          'Organizing lighting, framing and final details.',
          'Choosing the best details to make everything look even better.',
          'Preparing a polished result to appear here.',
          'Adjusting colors, contrast and expression with extra care.',
          'Almost there: your image is getting the final touches.',
          'Adding a special touch to make your image look even more amazing.',
          'Refining every detail to deliver a beautiful result.',
        ),
        'waiting_message' => 'Your request was sent. Please wait just a little longer.',
        'poll_failed_message' => 'Failed to check the job progress.',
        'query_failed_message' => 'Failed to check the job.',
        'temporary_result' => 'Temporary result',
        'until' => 'until',
        'media_library' => 'Media library',
        'download_label' => 'Download image',
        'upload_label' => 'Upload your photos',
        'upload_required' => 'This template requires at least one photo.',
        'upload_optional' => 'A photo is optional for this template.',
        'upload_subhint' => 'You can upload up to %d images.',
        'selected_photos' => 'Selected photos',
        'result_image_label' => 'Generated image',
      );
    }

    return array(
      'tip' => 'Dica: use fotos nítidas, com boa iluminação e pouco filtro. Se houver rosto, tente enviar imagens em que ele apareça bem.',
      'loading_title' => 'Gerando sua imagem',
      'loading_messages' => array(
        'Estamos gerando a sua imagem com muito carinho.',
        'Organizando luz, enquadramento e detalhes finais.',
        'Escolhendo os melhores detalhes para deixar tudo ainda mais bonito.',
        'Preparando um resultado caprichado para aparecer aqui.',
        'Ajustando cores, contraste e expressão com bastante cuidado.',
        'Quase lá: sua imagem está recebendo os últimos retoques.',
        'Dando um toque especial para a sua imagem ficar ainda mais incrível.',
        'Refinando cada detalhe para entregar um resultado bem bonito.',
      ),
      'waiting_message' => 'Seu pedido foi enviado. Aguarde só mais um pouquinho.',
      'poll_failed_message' => 'Falha ao consultar o andamento do job.',
      'query_failed_message' => 'Falha ao consultar o job.',
      'temporary_result' => 'Resultado temporário',
      'until' => 'até',
      'media_library' => 'Biblioteca de mídia',
      'download_label' => 'Baixar imagem',
      'upload_label' => 'Envie suas fotos',
      'upload_required' => 'Este template exige pelo menos uma foto.',
      'upload_optional' => 'A foto é opcional para este template.',
      'upload_subhint' => 'Você pode enviar até %d imagens.',
      'selected_photos' => 'Fotos selecionadas',
      'result_image_label' => 'Imagem gerada',
    );
  }

  /**
   * @param array<string, mixed> $fallback
   * @return array<string, array<string, string>>
   */
  private function get_default_template_translations(array $fallback = array()) {
    $translations = array();

    foreach ($this->get_template_languages() as $locale => $label) {
      $translations[$locale] = array(
        'label' => !empty($fallback['label']) && 'pt_BR' === $locale ? (string) $fallback['label'] : '',
        'description' => !empty($fallback['description']) && 'pt_BR' === $locale ? (string) $fallback['description'] : '',
        'locked_prompt' => !empty($fallback['locked_prompt']) && 'pt_BR' === $locale ? (string) $fallback['locked_prompt'] : '',
      );
    }

    return $translations;
  }

  /**
   * @param mixed $translations
   * @param array<string, mixed> $fallback
   * @return array<string, array<string, string>>
   */
  private function sanitize_template_translations($translations, array $fallback = array()) {
    $normalized = $this->get_default_template_translations($fallback);

    if (!is_array($translations)) {
      return $normalized;
    }

    foreach ($this->get_template_languages() as $locale => $language_label) {
      $data = !empty($translations[$locale]) && is_array($translations[$locale]) ? $translations[$locale] : array();

      $normalized[$locale] = array(
        'label' => !empty($data['label']) ? sanitize_text_field((string) $data['label']) : $normalized[$locale]['label'],
        'description' => !empty($data['description']) ? sanitize_text_field((string) $data['description']) : $normalized[$locale]['description'],
        'locked_prompt' => !empty($data['locked_prompt']) ? sanitize_textarea_field((string) $data['locked_prompt']) : $normalized[$locale]['locked_prompt'],
      );
    }

    return $normalized;
  }

  /**
   * @param array<string, mixed> $template
   * @param string $field
   * @param string $locale
   * @return string
   */
  private function get_localized_template_field(array $template, $field, $locale = '') {
    $resolved_locale = $locale ? $locale : $this->resolve_template_language();

    if (!empty($template['translations'][$resolved_locale][$field])) {
      return (string) $template['translations'][$resolved_locale][$field];
    }

    return !empty($template[$field]) ? (string) $template[$field] : '';
  }

  /**
   * @return string
   */
  private function resolve_template_language() {
    $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
    $locale = is_string($locale) ? strtolower($locale) : '';

    if (0 === strpos($locale, 'pt')) {
      return 'pt_BR';
    }

    if (0 === strpos($locale, 'es')) {
      return 'es_ES';
    }

    return 'en_US';
  }

  /**
   * @return FCRS_Plugin
   */
  public static function get_instance() {
    if (null === self::$instance) {
      self::$instance = new self();
    }

    return self::$instance;
  }

  private function __construct() {
    add_shortcode(self::SHORTCODE, array($this, 'render_shortcode'));
    add_action('admin_post_' . self::GENERATE_ACTION, array($this, 'handle_request'));
    add_action('admin_post_nopriv_' . self::GENERATE_ACTION, array($this, 'handle_request'));
    add_action('wp_ajax_' . self::JOB_STATUS_ACTION, array($this, 'handle_job_status'));
    add_action('wp_ajax_nopriv_' . self::JOB_STATUS_ACTION, array($this, 'handle_job_status'));
    add_action('admin_post_' . self::SAVE_SETTINGS_ACTION, array($this, 'handle_settings_save'));
    add_action('admin_post_' . self::SAVE_TEMPLATE_ACTION, array($this, 'handle_template_save'));
    add_action('admin_post_' . self::DELETE_TEMPLATE_ACTION, array($this, 'handle_template_delete'));
    add_action('admin_menu', array($this, 'register_admin_page'));
    add_action('add_meta_boxes', array($this, 'register_meta_boxes'));
    add_action('save_post', array($this, 'save_article_meta'));
    add_action('init', array($this, 'register_blocks'));
  }

  public function register_admin_page() {
    add_management_page(
      'Menezes Studio',
      'Menezes Studio',
      'manage_options',
      self::PAGE_SLUG,
      array($this, 'render_admin_page')
    );
  }

  public function register_meta_boxes() {
    $screens = array('post', 'page');

    foreach ($screens as $screen) {
      add_meta_box(
        'fcrs-article-config',
        'Menezes Studio',
        array($this, 'render_article_meta_box'),
        $screen,
        'side',
        'default'
      );
    }
  }

  public function register_blocks() {
    wp_register_script(
      'fcrs-block-editor',
      FCRS_PLUGIN_URL . 'assets/fcrs-block-editor.js',
      array('wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor'),
      '1.8.11',
      true
    );

    wp_localize_script(
      'fcrs-block-editor',
      'FCRSBlockData',
      array(
        'templates' => $this->get_block_template_options(),
        'models' => $this->get_block_model_options(),
      )
    );

    register_block_type(
      'felipe-ai-studio/generator',
      array(
        'api_version' => 2,
        'editor_script' => 'fcrs-block-editor',
        'render_callback' => array($this, 'render_generator_block'),
        'attributes' => array(
          'templateKey' => array(
            'type' => 'string',
            'default' => '',
          ),
          'model' => array(
            'type' => 'string',
            'default' => '',
          ),
          'title' => array(
            'type' => 'string',
            'default' => 'Gerador de imagem',
          ),
          'submitLabel' => array(
            'type' => 'string',
            'default' => 'Gerar imagem',
          ),
        ),
      )
    );
  }

  /**
   * @param \WP_Post $post
   * @return void
   */
  public function render_article_meta_box($post) {
    $article_config = $this->get_article_config($post->ID);
    $templates = $this->get_templates_by_type('image');
    $models = $this->get_models_by_type('image');

    wp_nonce_field(self::META_NONCE, 'fcrs_article_meta_nonce');
    include FCRS_PLUGIN_DIR . 'templates/article-meta-box-v3.php';
  }

  /**
   * @param int $post_id
   * @return void
   */
  public function save_article_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
      return;
    }

    if (wp_is_post_revision($post_id)) {
      return;
    }

    if (!isset($_POST['fcrs_article_meta_nonce'])) {
      return;
    }

    if (!wp_verify_nonce((string) wp_unslash($_POST['fcrs_article_meta_nonce']), self::META_NONCE)) {
      return;
    }

    if (!current_user_can('edit_post', $post_id)) {
      return;
    }

    $enabled = !empty($_POST['fcrs_enabled']) ? '1' : '0';
    $template_key = isset($_POST['fcrs_template_key'])
      ? sanitize_key(wp_unslash($_POST['fcrs_template_key']))
      : '';
    $model_override = isset($_POST['fcrs_model_override'])
      ? sanitize_text_field((string) wp_unslash($_POST['fcrs_model_override']))
      : '';

    $templates = $this->get_templates_by_type('image');
    $models = $this->get_models_by_type('image');

    if (!array_key_exists($template_key, $templates)) {
      $template_key = '';
    }

    if ($model_override && !array_key_exists($model_override, $models)) {
      $model_override = '';
    }

    update_post_meta($post_id, self::POST_META_ENABLED, $enabled);
    update_post_meta($post_id, self::POST_META_TEMPLATE, $template_key);
    update_post_meta($post_id, self::POST_META_MODEL, $model_override);
  }

  /**
   * @param array<string, mixed> $atts
   * @return string
   */
  public function render_shortcode($atts) {
    $atts = shortcode_atts(
      array(
        'title' => 'Gerador de imagem',
        'submit_label' => 'Gerar imagem',
      ),
      $atts,
      self::SHORTCODE
    );

    $post_id = get_queried_object_id();

    if (!$post_id) {
      return '';
    }

    $article_config = $this->get_article_config($post_id);

    if (!$article_config['enabled'] || empty($article_config['template_key'])) {
      if (current_user_can('edit_post', $post_id)) {
        return '<p>Menezes Studio: selecione um template neste artigo para exibir o gerador.</p>';
      }

      return '';
    }

    $template = $this->get_template($article_config['template_key']);

    if (!$template) {
      if (current_user_can('edit_post', $post_id)) {
        return '<p>Menezes Studio: o template selecionado neste artigo nao existe mais.</p>';
      }

      return '';
    }

    return $this->render_generator_panel(
      $article_config['template_key'],
      $article_config['model_override'],
      array(
        'title' => (string) $atts['title'],
        'submit_label' => (string) $atts['submit_label'],
        'description' => '',
      )
    );
  }

  /**
   * @param array<string, mixed> $attributes
   * @return string
   */
  public function render_generator_block($attributes) {
    $template_key = !empty($attributes['templateKey'])
      ? sanitize_key((string) $attributes['templateKey'])
      : '';
    $model_override = !empty($attributes['model'])
      ? sanitize_text_field((string) $attributes['model'])
      : '';
    $title = !empty($attributes['title'])
      ? sanitize_text_field((string) $attributes['title'])
      : 'Gerador de imagem';
    $submit_label = !empty($attributes['submitLabel'])
      ? sanitize_text_field((string) $attributes['submitLabel'])
      : 'Gerar imagem';

    if ('' === $template_key) {
      if (is_admin() && current_user_can('edit_posts')) {
        return '<p>Menezes Studio: selecione um template no bloco.</p>';
      }

      return '';
    }

    $template = $this->get_template($template_key);

    if (!$template) {
      if (is_admin() && current_user_can('edit_posts')) {
        return '<p>Menezes Studio: o template selecionado no bloco nao existe mais.</p>';
      }

      return '';
    }

    return $this->render_generator_panel(
      $template_key,
      $model_override,
      array(
        'title' => $title,
        'submit_label' => $submit_label,
        'description' => '',
      )
    );
  }

  public function render_admin_page() {
    if (!current_user_can('manage_options')) {
      return;
    }

    $this->enqueue_assets();

    $config = $this->get_config();
    $saved_settings = $this->get_saved_settings();
    $templates = $this->get_templates();
    $image_templates = $this->get_templates_by_type('image');
    $models_by_type = $this->get_models_catalog();
    $result = $this->get_result();
    $result_token = $this->get_result_token();
    $editing_template_key = isset($_GET['fcrs_edit_template'])
      ? sanitize_key(wp_unslash($_GET['fcrs_edit_template']))
      : '';
    $editing_template = $editing_template_key ? $this->get_template($editing_template_key) : null;
    $selected_generation_type = isset($_GET['fcrs_generation_type'])
      ? sanitize_key(wp_unslash($_GET['fcrs_generation_type']))
      : 'image';
    $selected_template_key = isset($_GET['fcrs_template'])
      ? sanitize_key(wp_unslash($_GET['fcrs_template']))
      : '';
    $selected_model = isset($_GET['fcrs_model'])
      ? sanitize_text_field((string) wp_unslash($_GET['fcrs_model']))
      : '';
    $selected_prompt = !empty($result['input_prompt'])
      ? (string) $result['input_prompt']
      : '';
    $selected_image_options = !empty($result['input_image_options']) && is_array($result['input_image_options'])
      ? $result['input_image_options']
      : $this->get_default_image_options();
    $save_to_media = !empty($_GET['fcrs_save_media']);
    $settings_action_url = esc_url(admin_url('admin-post.php'));
    $generate_action_url = esc_url(admin_url('admin-post.php'));
    $template_action_url = esc_url(admin_url('admin-post.php'));
    $template_form_values = $this->get_template_form_values($editing_template_key, $editing_template);
    $template_languages = $this->get_template_languages();
    $aspect_ratio_options = $this->get_aspect_ratio_options();
    $image_size_options = $this->get_image_size_options();
    $format_options = $this->get_format_options();
    $process_type_options = $this->get_process_type_options();

    $settings_values = array(
      'endpoint' => $saved_settings['endpoint'] ? $saved_settings['endpoint'] : $config['endpoint'],
      'secret' => $saved_settings['secret'] ? $saved_settings['secret'] : $config['secret'],
      'timeout' => $saved_settings['timeout'] ? $saved_settings['timeout'] : $config['timeout'],
      'process_type' => $saved_settings['process_type'] ? $saved_settings['process_type'] : $config['process_type'],
    );

    echo '<div class="wrap">';
    echo '<h1>Menezes Studio</h1>';

    if (!empty($_GET['fcrs_settings_saved'])) {
      echo '<div class="notice notice-success is-dismissible"><p>Configuracoes salvas.</p></div>';
    }

    include FCRS_PLUGIN_DIR . 'templates/admin-panel-v3.php';
    echo '</div>';
  }

  public function handle_settings_save() {
    if (!current_user_can('manage_options')) {
      wp_die('Voce nao tem permissao para alterar estas configuracoes.');
    }

    check_admin_referer(self::SETTINGS_NONCE, 'fcrs_settings_nonce');

    $endpoint = isset($_POST['fcrs_endpoint'])
      ? esc_url_raw(trim((string) wp_unslash($_POST['fcrs_endpoint'])))
      : '';
    $secret = isset($_POST['fcrs_secret'])
      ? trim((string) wp_unslash($_POST['fcrs_secret']))
      : '';
    $timeout = isset($_POST['fcrs_timeout'])
      ? max(30, (int) wp_unslash($_POST['fcrs_timeout']))
      : 120;
    $process_type = isset($_POST['fcrs_process_type'])
      ? $this->normalize_process_type((string) wp_unslash($_POST['fcrs_process_type']))
      : self::DEFAULT_PROCESS_TYPE;

    update_option(
      self::OPTION_KEY,
      array(
        'endpoint' => $endpoint,
        'secret' => $secret,
        'timeout' => $timeout,
        'process_type' => $process_type,
      ),
      false
    );

    wp_safe_redirect(admin_url('tools.php?page=' . self::PAGE_SLUG . '&fcrs_settings_saved=1'));
    exit;
  }

  public function handle_template_save() {
    if (!current_user_can('manage_options')) {
      wp_die('Voce nao tem permissao para alterar os templates.');
    }

    check_admin_referer(self::TEMPLATE_NONCE, 'fcrs_template_nonce');

    $templates = $this->get_templates();
    $image_models = $this->get_models_by_type('image');
    $original_key = isset($_POST['fcrs_template_original_key'])
      ? sanitize_key(wp_unslash($_POST['fcrs_template_original_key']))
      : '';
    $label = isset($_POST['fcrs_template_label'])
      ? sanitize_text_field((string) wp_unslash($_POST['fcrs_template_label']))
      : '';
    $requested_key = isset($_POST['fcrs_template_key'])
      ? sanitize_key(wp_unslash($_POST['fcrs_template_key']))
      : '';
    $description = isset($_POST['fcrs_template_description'])
      ? sanitize_text_field((string) wp_unslash($_POST['fcrs_template_description']))
      : '';
    $locked_prompt = isset($_POST['fcrs_locked_prompt'])
      ? sanitize_textarea_field((string) wp_unslash($_POST['fcrs_locked_prompt']))
      : '';
    $default_model = isset($_POST['fcrs_default_model'])
      ? sanitize_text_field((string) wp_unslash($_POST['fcrs_default_model']))
      : '';
    $require_reference = !empty($_POST['fcrs_template_require_reference']) ? 1 : 0;
    $use_rewarded = !empty($_POST['fcrs_template_use_rewarded']) ? 1 : 0;
    $ui_language = isset($_POST['fcrs_template_ui_language'])
      ? $this->normalize_interface_language((string) wp_unslash($_POST['fcrs_template_ui_language']))
      : 'pt_BR';
    $image_options = $this->sanitize_image_options($_POST, 'fcrs_template_');

    if ('' === $label) {
      $this->redirect_admin_page(array('fcrs_template_error' => 'missing_label'));
    }

    if ('' === $locked_prompt) {
      $this->redirect_admin_page(array('fcrs_template_error' => 'missing_prompt'));
    }

    if (!isset($image_models[$default_model])) {
      $default_model = 'gemini-3-pro-image-preview';
    }

    $template_key = $this->get_unique_template_key($requested_key ? $requested_key : $label, $templates, $original_key);

    if ($original_key && $original_key !== $template_key && isset($templates[$original_key])) {
      unset($templates[$original_key]);
    }

    $templates[$template_key] = array(
      'type' => 'image',
      'label' => $label,
      'description' => $description,
      'locked_prompt' => $locked_prompt,
      'default_model' => $default_model,
      'require_reference' => $require_reference,
      'use_rewarded' => $use_rewarded,
      'ui_language' => $ui_language,
      'image_options' => $image_options,
    );

    update_option(self::TEMPLATES_OPTION_KEY, $this->normalize_templates($templates), false);

    $this->redirect_admin_page(
      array(
        'fcrs_template_saved' => '1',
        'fcrs_edit_template' => $template_key,
      )
    );
  }

  public function handle_template_delete() {
    if (!current_user_can('manage_options')) {
      wp_die('Voce nao tem permissao para remover templates.');
    }

    check_admin_referer(self::DELETE_TEMPLATE_NONCE, 'fcrs_delete_template_nonce');

    $template_key = isset($_POST['fcrs_template_key'])
      ? sanitize_key(wp_unslash($_POST['fcrs_template_key']))
      : '';

    if ('' === $template_key) {
      $this->redirect_admin_page(array('fcrs_template_error' => 'missing_template'));
    }

    if ($this->count_template_usage($template_key) > 0) {
      $this->redirect_admin_page(array('fcrs_template_error' => 'template_in_use'));
    }

    $templates = $this->get_templates();

    if (isset($templates[$template_key])) {
      unset($templates[$template_key]);
      update_option(self::TEMPLATES_OPTION_KEY, $this->normalize_templates($templates), false);
    }

    $this->redirect_admin_page(array('fcrs_template_deleted' => '1'));
  }

  public function handle_request() {
    check_admin_referer(self::NONCE, 'fcrs_nonce');

    $redirect_url = $this->get_redirect_url();
    $generation_type = isset($_POST['generationType'])
      ? sanitize_key(wp_unslash($_POST['generationType']))
      : 'image';
    $template_key = isset($_POST['templateKey'])
      ? sanitize_key(wp_unslash($_POST['templateKey']))
      : '';
    $manual_prompt = isset($_POST['manualPrompt'])
      ? sanitize_textarea_field((string) wp_unslash($_POST['manualPrompt']))
      : '';
    $selected_model = isset($_POST['model'])
      ? sanitize_text_field((string) wp_unslash($_POST['model']))
      : '';
    $request_image_options = $this->sanitize_image_options($_POST, 'fcrs_test_', false);
    $save_to_media = !empty($_POST['saveToMedia']) ? 1 : 0;
    $config = $this->get_config();

    if (!$config['ready']) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => 'Configure a URL do endpoint e a chave antes de usar o plugin.',
        ),
        $template_key,
        $selected_model,
        $generation_type,
        $save_to_media
      );
    }

    if ('video' === $generation_type) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => 'A interface de video foi preparada, mas a API atual ainda nao suporta geracao de video.',
        ),
        $template_key,
        $selected_model,
        $generation_type,
        $save_to_media
      );
    }

    $templates = $this->get_templates();

    if ($template_key && !array_key_exists($template_key, $templates)) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => 'Template invalido.',
        ),
        $template_key,
        $selected_model,
        $generation_type,
        $save_to_media
      );
    }

    $models = $this->get_models_by_type($generation_type);
    $template = $template_key ? $templates[$template_key] : null;
    $model_to_use = $selected_model;

    if (!$model_to_use || !array_key_exists($model_to_use, $models)) {
      $model_to_use = $template && !empty($template['default_model'])
        ? $template['default_model']
        : 'gemini-3-pro-image-preview';
    }

    $prompt_parts = array();

    if ($template && !empty($template['locked_prompt'])) {
      $prompt_parts[] = (string) $template['locked_prompt'];
    }

    if ('' !== trim($manual_prompt)) {
      $prompt_parts[] = trim($manual_prompt);
    }

    if (empty($prompt_parts)) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => 'Selecione um template ou preencha um prompt para o teste.',
        ),
        $template_key,
        $model_to_use,
        $generation_type,
        $save_to_media
      );
    }

    $payload = array(
      'model' => $model_to_use,
      'userPrompt' => implode("\n\n", $prompt_parts),
    );
    $image_options = $this->merge_image_options(
      $template ? $this->extract_template_image_options($template) : array(),
      $request_image_options
    );

    if (!empty($image_options)) {
      $payload['imageOptions'] = $image_options;
    }

    $reference_images = $this->read_reference_images();

    if (is_wp_error($reference_images)) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => $reference_images->get_error_message(),
        ),
        $template_key,
        $model_to_use,
        $generation_type,
        $save_to_media
      );
    }

    if ($template && !empty($template['require_reference']) && empty($reference_images)) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => 'Este template exige o envio de pelo menos uma foto.',
        ),
        $template_key,
        $model_to_use,
        $generation_type,
        $save_to_media
      );
    }

    if (!empty($reference_images)) {
      $payload['referenceImages'] = $reference_images;
    }

    $process_type = !empty($config['process_type'])
      ? $this->normalize_process_type((string) $config['process_type'])
      : self::DEFAULT_PROCESS_TYPE;
    $response = wp_remote_post(
      '2' === $process_type
        ? $this->build_endpoint_url($config['endpoint'], '/jobs')
        : $this->build_endpoint_url($config['endpoint']),
      array(
        'timeout' => $config['timeout'],
        'headers' => array(
          'Content-Type' => 'application/json',
          'X-Site-Secret' => $config['secret'],
        ),
        'body' => wp_json_encode($payload),
      )
    );

    if (is_wp_error($response)) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => 'Falha ao chamar o endpoint: ' . $response->get_error_message(),
        ),
        $template_key,
        $model_to_use,
        $generation_type,
        $save_to_media
      );
    }

    $status_code = (int) wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($status_code < 200 || $status_code >= 300) {
      $message = is_array($data) && !empty($data['error'])
        ? (string) $data['error']
        : 'O endpoint respondeu com erro.';
      $details = is_array($data) && !empty($data['details'])
        ? ' ' . (string) $data['details']
        : '';

      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => trim($message . $details),
        ),
        $template_key,
        $model_to_use,
        $generation_type,
        $save_to_media
      );
    }

    if ('2' === $process_type) {
      if (!is_array($data) || empty($data['jobId'])) {
        $this->redirect_with_result(
          $redirect_url,
          array(
            'status' => 'error',
            'message' => 'O endpoint nao devolveu um job valido.',
          ),
          $template_key,
          $model_to_use,
          $generation_type,
          $save_to_media
        );
      }

      $result = array(
        'status' => !empty($data['status']) ? (string) $data['status'] : 'queued',
        'message' => 'Geracao iniciada. O resultado sera atualizado automaticamente.',
        'job_id' => (string) $data['jobId'],
        'model' => $model_to_use,
        'template_label' => $template ? $template['label'] : '',
        'text' => '',
        'input_image_options' => $image_options,
        'save_to_media' => $save_to_media ? 1 : 0,
        'process_type' => '2',
        'used_reference_image' => !empty($reference_images) ? 1 : 0,
        'reference_image_count' => count($reference_images),
      );

      $this->redirect_with_result($redirect_url, $result, $template_key, $model_to_use, $generation_type, $save_to_media);
    }

    if (!is_array($data) || empty($data['imageBase64']) || empty($data['mimeType'])) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => 'O endpoint nao devolveu uma imagem valida.',
        ),
        $template_key,
        $model_to_use,
        $generation_type,
        $save_to_media
      );
    }

    $preview = $this->save_preview_file((string) $data['imageBase64'], (string) $data['mimeType']);

    if (is_wp_error($preview)) {
      $this->redirect_with_result(
        $redirect_url,
        array(
          'status' => 'error',
          'message' => $preview->get_error_message(),
        ),
        $template_key,
        $model_to_use,
        $generation_type,
        $save_to_media
      );
    }

    $result = array(
      'status' => 'success',
      'message' => 'Imagem gerada com sucesso.',
      'model' => !empty($data['model']) ? (string) $data['model'] : $model_to_use,
      'template_label' => $template ? $template['label'] : '',
      'preview_url' => $preview['url'],
      'mime_type' => (string) $data['mimeType'],
      'text' => !empty($data['text']) ? wp_strip_all_tags((string) $data['text']) : '',
      'input_image_options' => $image_options,
      'save_to_media' => $save_to_media ? 1 : 0,
      'remote_result' => 0,
      'temporary_result' => 0,
      'process_type' => '1',
      'used_reference_image' => !empty($reference_images) ? 1 : 0,
      'reference_image_count' => count($reference_images),
      'download_url' => $preview['url'],
    );

    if ($save_to_media) {
      $attachment_id = $this->create_media_attachment($preview['file'], $preview['url'], (string) $data['mimeType']);

      if (is_wp_error($attachment_id)) {
        $result['status'] = 'warning';
        $result['message'] = 'A imagem foi gerada, mas nao foi possivel salvar na biblioteca de midia.';
        $result['text'] = trim($result['text'] . ' ' . $attachment_id->get_error_message());
      } else {
        $result['attachment_id'] = $attachment_id;
      }
    }

    $this->redirect_with_result($redirect_url, $result, $template_key, $model_to_use, $generation_type, $save_to_media);
  }

  public function handle_job_status() {
    check_ajax_referer(self::STATUS_NONCE, 'security');

    $job_id = isset($_POST['jobId'])
      ? sanitize_text_field((string) wp_unslash($_POST['jobId']))
      : '';
    $result_token = isset($_POST['resultToken'])
      ? sanitize_text_field((string) wp_unslash($_POST['resultToken']))
      : '';

    if ('' === $job_id || '' === $result_token) {
      wp_send_json_error(array(
        'message' => 'Job invalido.',
      ), 400);
    }

    $config = $this->get_config();

    if (!$config['ready']) {
      wp_send_json_error(array(
        'message' => 'Configure o endpoint e a chave antes de consultar jobs.',
      ), 400);
    }

    $current_result = $this->get_result_by_token($result_token);

    if (!is_array($current_result)) {
      wp_send_json_error(array(
        'message' => 'O resultado local desse job expirou. Gere novamente.',
      ), 410);
    }

    $status_response = wp_remote_get(
      $this->build_endpoint_url($config['endpoint'], '/jobs/' . rawurlencode($job_id)),
      array(
        'timeout' => max(30, $config['timeout']),
        'headers' => array(
          'X-Site-Secret' => $config['secret'],
        ),
      )
    );

    if (is_wp_error($status_response)) {
      wp_send_json_error(array(
        'message' => 'Falha ao consultar o job: ' . $status_response->get_error_message(),
      ), 502);
    }

    $status_code = (int) wp_remote_retrieve_response_code($status_response);
    $status_body = wp_remote_retrieve_body($status_response);
    $status_data = json_decode($status_body, true);

    if ($status_code < 200 || $status_code >= 300 || !is_array($status_data)) {
      $message = is_array($status_data) && !empty($status_data['error'])
        ? (string) $status_data['error']
        : 'Nao foi possivel consultar o status do job.';
      wp_send_json_error(array(
        'message' => $message,
      ), $status_code >= 400 ? $status_code : 502);
    }

    $job_status = !empty($status_data['status']) ? (string) $status_data['status'] : 'unknown';

    if ('queued' === $job_status || 'processing' === $job_status) {
      $current_result['status'] = $job_status;
      $current_result['message'] = !empty($status_data['message'])
        ? (string) $status_data['message']
        : ('queued' === $job_status ? 'Job na fila.' : 'Job em processamento.');
      $this->store_result_by_token($result_token, $current_result);

      wp_send_json_success(array(
        'jobId' => $job_id,
        'status' => $job_status,
        'terminal' => false,
        'message' => $current_result['message'],
      ));
    }

    if ('failed' === $job_status) {
      $current_result['status'] = 'error';
      $current_result['message'] = !empty($status_data['error'])
        ? (string) $status_data['error']
        : 'O job falhou.';
      $this->store_result_by_token($result_token, $current_result);

      wp_send_json_success(array(
        'jobId' => $job_id,
        'status' => 'error',
        'terminal' => true,
        'message' => $current_result['message'],
      ));
    }

    if ('completed' !== $job_status) {
      wp_send_json_error(array(
        'message' => 'Status de job nao suportado: ' . $job_status,
      ), 500);
    }

    if (!empty($current_result['preview_url'])) {
      wp_send_json_success(array(
        'jobId' => $job_id,
        'status' => 'success',
        'terminal' => true,
        'message' => !empty($current_result['message']) ? (string) $current_result['message'] : 'Imagem pronta.',
        'result' => $current_result,
      ));
    }

    $resolved_result = $this->resolve_completed_job_result($config, $job_id, $status_data, $current_result);

    if (is_wp_error($resolved_result)) {
      wp_send_json_error(array(
        'message' => $resolved_result->get_error_message(),
      ), 500);
    }

    $this->store_result_by_token($result_token, $resolved_result);

    wp_send_json_success(array(
      'jobId' => $job_id,
      'status' => !empty($resolved_result['status']) ? (string) $resolved_result['status'] : 'success',
      'terminal' => true,
      'message' => !empty($resolved_result['message']) ? (string) $resolved_result['message'] : 'Imagem pronta.',
      'result' => $resolved_result,
    ));
  }

  /**
   * @return array<string, mixed>
   */
  private function get_saved_settings() {
    $settings = get_option(self::OPTION_KEY, array());

    if (!is_array($settings)) {
      $settings = array();
    }

    return array(
      'endpoint' => !empty($settings['endpoint']) ? (string) $settings['endpoint'] : '',
      'secret' => !empty($settings['secret']) ? (string) $settings['secret'] : '',
      'timeout' => !empty($settings['timeout']) ? max(30, (int) $settings['timeout']) : 120,
      'process_type' => !empty($settings['process_type']) ? $this->normalize_process_type((string) $settings['process_type']) : self::DEFAULT_PROCESS_TYPE,
    );
  }

  /**
   * @return array<string, mixed>
   */
  private function get_config() {
    $saved = $this->get_saved_settings();
    $endpoint = $saved['endpoint'];
    $secret = $saved['secret'];
    $timeout = $saved['timeout'];
    $process_type = $saved['process_type'];
    $source = 'plugin';

    if ('' === $endpoint) {
      if (defined('FCRS_CLOUD_RUN_ENDPOINT') && FCRS_CLOUD_RUN_ENDPOINT) {
        $endpoint = (string) FCRS_CLOUD_RUN_ENDPOINT;
        $source = 'wp-config';
      } elseif (defined('CLOUD_RUN_ENDPOINT') && CLOUD_RUN_ENDPOINT) {
        $endpoint = (string) CLOUD_RUN_ENDPOINT;
        $source = 'wp-config';
      }
    }

    if ('' === $secret) {
      if (defined('FCRS_CLOUD_RUN_SHARED_SECRET') && FCRS_CLOUD_RUN_SHARED_SECRET) {
        $secret = (string) FCRS_CLOUD_RUN_SHARED_SECRET;
      } elseif (defined('CLOUD_RUN_SHARED_SECRET') && CLOUD_RUN_SHARED_SECRET) {
        $secret = (string) CLOUD_RUN_SHARED_SECRET;
      }
    }

    if (120 === $timeout) {
      if (defined('FCRS_CLOUD_RUN_TIMEOUT') && FCRS_CLOUD_RUN_TIMEOUT) {
        $timeout = max(30, (int) FCRS_CLOUD_RUN_TIMEOUT);
      } elseif (defined('CLOUD_RUN_TIMEOUT') && CLOUD_RUN_TIMEOUT) {
        $timeout = max(30, (int) CLOUD_RUN_TIMEOUT);
      }
    }

    return array(
      'endpoint' => $endpoint,
      'secret' => $secret,
      'timeout' => $timeout,
      'process_type' => $process_type,
      'ready' => '' !== $endpoint && '' !== $secret,
      'source' => $source,
    );
  }

  /**
   * @return array<string, string>
   */
  private function get_process_type_options() {
    return array(
      '1' => '1 - Modo antigo',
      '2' => '2 - Modo novo em configuracao',
    );
  }

  /**
   * @param string $process_type
   * @return string
   */
  private function normalize_process_type($process_type) {
    return '2' === $process_type ? '2' : self::DEFAULT_PROCESS_TYPE;
  }

  /**
   * @param string $process_type
   * @return string
   */
  private function get_process_type_label($process_type) {
    $options = $this->get_process_type_options();
    $normalized = $this->normalize_process_type($process_type);

    return isset($options[$normalized]) ? $options[$normalized] : $options[self::DEFAULT_PROCESS_TYPE];
  }

  /**
   * @param array<string, mixed> $result
   * @return array<string, string>
   */
  private function get_result_parameters(array $result) {
    $rows = array();
    $image_options = !empty($result['input_image_options']) && is_array($result['input_image_options'])
      ? $result['input_image_options']
      : array();
    $format_options = $this->get_format_options();

    if (!empty($result['process_type'])) {
      $rows['Tipo de processo'] = $this->get_process_type_label((string) $result['process_type']);
    }

    if (!empty($result['model'])) {
      $rows['Modelo'] = (string) $result['model'];
    }

    if (!empty($result['template_label'])) {
      $rows['Template'] = (string) $result['template_label'];
    }

    if (!empty($image_options['imageSize'])) {
      $rows['Tamanho da imagem'] = (string) $image_options['imageSize'];
    }

    if (!empty($image_options['aspectRatio'])) {
      $rows['Proporcao'] = (string) $image_options['aspectRatio'];
    }

    if (!empty($image_options['outputMimeType'])) {
      $output_mime_type = (string) $image_options['outputMimeType'];
      $rows['Formato'] = !empty($format_options[$output_mime_type])
        ? (string) $format_options[$output_mime_type]
        : $output_mime_type;

      if ('image/jpeg' === $output_mime_type && isset($image_options['compressionQuality'])) {
        $rows['Qualidade JPEG'] = (string) ((int) $image_options['compressionQuality']);
      }
    }

    if (isset($result['used_reference_image'])) {
      $rows['Imagem de referencia'] = !empty($result['used_reference_image']) ? 'Sim' : 'Nao';
    }

    return $rows;
  }

  /**
   * @return array<string, array<string, mixed>>
   */
  private function get_templates() {
    $templates = get_option(self::TEMPLATES_OPTION_KEY, null);

    if (null === $templates) {
      return $this->get_default_templates();
    }

    if (!is_array($templates)) {
      return array();
    }

    return $this->normalize_templates($templates);
  }

  /**
   * @return array<string, array<string, mixed>>
   */
  private function get_default_templates() {
    return array(
      'luxury_product_ad' => array(
        'type' => 'image',
      'label' => 'Anuncio Premium de Produto',
        'description' => 'Imagem publicitaria com cara de campanha premium para produto.',
        'locked_prompt' => 'Use a premium editorial advertising direction, elegant lighting, strong product focus and polished commercial finish.',
        'ui_language' => 'pt_BR',
        'default_model' => 'gemini-3-pro-image-preview',
        'image_options' => array(
          'aspectRatio' => '1:1',
          'imageSize' => '2K',
          'outputMimeType' => 'image/png',
          'compressionQuality' => 75,
        ),
      ),
      'character_editorial_portrait' => array(
        'type' => 'image',
      'label' => 'Retrato Editorial de Personagem',
        'description' => 'Retrato visual forte, focado em identidade, rosto e presenca.',
        'locked_prompt' => 'Create an editorial portrait with premium lighting, strong identity preservation and polished magazine-style finishing.',
        'ui_language' => 'pt_BR',
        'default_model' => 'gemini-3-pro-image-preview',
        'image_options' => array(
          'aspectRatio' => '3:4',
          'imageSize' => '2K',
          'outputMimeType' => 'image/png',
          'compressionQuality' => 75,
        ),
      ),
      'social_campaign_visual' => array(
        'type' => 'image',
      'label' => 'Criativo de Campanha Social',
        'description' => 'Visual pensado para redes sociais, mais chamativo e orientado a campanha.',
        'locked_prompt' => 'Create a bold social campaign visual with strong composition, clear focal subject and conversion-oriented ad aesthetics.',
        'ui_language' => 'pt_BR',
        'default_model' => 'gemini-3-pro-image-preview',
        'image_options' => array(
          'aspectRatio' => '4:5',
          'imageSize' => '2K',
          'outputMimeType' => 'image/png',
          'compressionQuality' => 75,
        ),
      ),
    );
  }

  /**
   * @param mixed $templates
   * @return array<string, array<string, mixed>>
   */
  private function normalize_templates($templates) {
    if (!is_array($templates)) {
      return array();
    }

    $normalized = array();

    foreach ($templates as $key => $template) {
      $normalized_key = sanitize_key((string) $key);
      $normalized_template = $this->normalize_template($template);

      if ('' === $normalized_key || empty($normalized_template)) {
        continue;
      }

      $normalized[$normalized_key] = $normalized_template;
    }

    return apply_filters('fcrs_templates_v3', $normalized);
  }

  /**
   * @param mixed $template
   * @return array<string, mixed>
   */
  private function normalize_template($template) {
    if (!is_array($template)) {
      return array();
    }

    $image_models = $this->get_models_by_type('image');
    $type = !empty($template['type']) && 'video' === $template['type'] ? 'video' : 'image';
    $default_model = !empty($template['default_model'])
      ? sanitize_text_field((string) $template['default_model'])
      : 'gemini-3-pro-image-preview';

    if ('image' === $type && !isset($image_models[$default_model])) {
      $default_model = 'gemini-3-pro-image-preview';
    }

    return array(
      'type' => $type,
      'label' => !empty($template['label']) ? sanitize_text_field((string) $template['label']) : '',
      'description' => !empty($template['description']) ? sanitize_text_field((string) $template['description']) : '',
      'locked_prompt' => !empty($template['locked_prompt']) ? sanitize_textarea_field((string) $template['locked_prompt']) : '',
      'default_model' => $default_model,
      'require_reference' => array_key_exists('require_reference', $template) ? !empty($template['require_reference']) : true,
      'use_rewarded' => array_key_exists('use_rewarded', $template) ? !empty($template['use_rewarded']) : true,
      'ui_language' => !empty($template['ui_language']) ? $this->normalize_interface_language((string) $template['ui_language']) : 'pt_BR',
      'image_options' => !empty($template['image_options']) && is_array($template['image_options'])
        ? $this->sanitize_image_options($template['image_options'], '', true)
        : $this->get_default_image_options(),
    );
  }

  /**
   * @param string $type
   * @return array<string, array<string, mixed>>
   */
  private function get_templates_by_type($type) {
    $filtered = array();

    foreach ($this->get_templates() as $key => $template) {
      if (!empty($template['type']) && $template['type'] === $type) {
        $filtered[$key] = $template;
      }
    }

    return $filtered;
  }

  /**
   * @return array<int, array<string, string>>
   */
  private function get_block_template_options() {
    $templates = $this->get_templates_by_type('image');
    $options = array();

    foreach ($templates as $template_key => $template_data) {
      $options[] = array(
        'value' => (string) $template_key,
        'label' => !empty($template_data['label']) ? (string) $template_data['label'] : (string) $template_key,
      );
    }

    return $options;
  }

  /**
   * @return array<int, array<string, string>>
   */
  private function get_block_model_options() {
    $models = $this->get_models_by_type('image');
    $options = array(
      array(
        'value' => '',
        'label' => 'Usar modelo padrao do template',
      ),
    );

    foreach ($models as $model_key => $model_label) {
      $options[] = array(
        'value' => (string) $model_key,
        'label' => (string) $model_label,
      );
    }

    return $options;
  }

  /**
   * @param string $key
   * @return array<string, mixed>|null
   */
  private function get_template($key) {
    $templates = $this->get_templates();

    return isset($templates[$key]) ? $templates[$key] : null;
  }

  /**
   * @return array<string, array<string, string>>
   */
  private function get_models_catalog() {
    return array(
      'image' => $this->get_models_by_type('image'),
      'video' => $this->get_models_by_type('video'),
    );
  }

  /**
   * @param string $type
   * @return array<string, string>
   */
  private function get_models_by_type($type) {
    if ('video' === $type) {
      return array(
        'veo-3.1-fast-generate-001' => 'Veo 3.1 Fast',
        'veo-3.1-generate-001' => 'Veo 3.1 Quality',
      );
    }

    return array(
      'gemini-3-pro-image-preview' => 'Gemini 3 Pro Image Preview',
      'gemini-2.5-flash-image' => 'Gemini 2.5 Flash Image',
      'imagen-4.0-fast-generate-001' => 'Imagen 4 Fast',
      'imagen-4.0-generate-001' => 'Imagen 4 Standard',
      'imagen-4.0-ultra-generate-001' => 'Imagen 4 Ultra',
    );
  }

  /**
   * @return array<string, string>
   */
  private function get_aspect_ratio_options() {
    return array(
      '1:1' => '1:1 Quadrado',
      '2:3' => '2:3 Retrato',
      '3:2' => '3:2 Paisagem',
      '3:4' => '3:4 Retrato',
      '4:3' => '4:3 Classico',
      '4:5' => '4:5 Social',
      '5:4' => '5:4 Classico',
      '9:16' => '9:16 Stories',
      '16:9' => '16:9 Widescreen',
      '21:9' => '21:9 Ultrawide',
    );
  }

  /**
   * @return array<string, string>
   */
  private function get_image_size_options() {
    return array(
      '1K' => '1K',
      '2K' => '2K',
      '4K' => '4K',
    );
  }

  /**
   * @return array<string, string>
   */
  private function get_format_options() {
    return array(
      'image/png' => 'PNG',
      'image/jpeg' => 'JPEG',
    );
  }

  /**
   * @param int $post_id
   * @return array<string, mixed>
   */
  private function get_article_config($post_id) {
    $enabled = '1' === (string) get_post_meta($post_id, self::POST_META_ENABLED, true);
    $template_key = (string) get_post_meta($post_id, self::POST_META_TEMPLATE, true);
    $model_override = (string) get_post_meta($post_id, self::POST_META_MODEL, true);

    return array(
      'enabled' => $enabled,
      'template_key' => $template_key,
      'model_override' => $model_override,
    );
  }

  /**
   * @param string $editing_template_key
   * @param array<string, mixed>|null $editing_template
   * @return array<string, string>
   */
  private function get_template_form_values($editing_template_key, $editing_template) {
    if (is_array($editing_template)) {
      return array(
        'original_key' => $editing_template_key,
        'key' => $editing_template_key,
        'label' => !empty($editing_template['label']) ? (string) $editing_template['label'] : '',
        'description' => !empty($editing_template['description']) ? (string) $editing_template['description'] : '',
        'locked_prompt' => !empty($editing_template['locked_prompt']) ? (string) $editing_template['locked_prompt'] : '',
        'default_model' => !empty($editing_template['default_model']) ? (string) $editing_template['default_model'] : 'gemini-3-pro-image-preview',
        'require_reference' => array_key_exists('require_reference', $editing_template) ? (!empty($editing_template['require_reference']) ? '1' : '0') : '1',
        'use_rewarded' => array_key_exists('use_rewarded', $editing_template) ? (!empty($editing_template['use_rewarded']) ? '1' : '0') : '1',
        'ui_language' => !empty($editing_template['ui_language']) ? $this->normalize_interface_language((string) $editing_template['ui_language']) : 'pt_BR',
        'aspect_ratio' => !empty($editing_template['image_options']['aspectRatio']) ? (string) $editing_template['image_options']['aspectRatio'] : self::DEFAULT_ASPECT_RATIO,
        'image_size' => !empty($editing_template['image_options']['imageSize']) ? (string) $editing_template['image_options']['imageSize'] : self::DEFAULT_IMAGE_SIZE,
        'output_mime_type' => !empty($editing_template['image_options']['outputMimeType']) ? (string) $editing_template['image_options']['outputMimeType'] : self::DEFAULT_IMAGE_FORMAT,
        'compression_quality' => !empty($editing_template['image_options']['compressionQuality']) ? (string) $editing_template['image_options']['compressionQuality'] : (string) self::DEFAULT_JPEG_QUALITY,
      );
    }

    return array(
      'original_key' => '',
      'key' => '',
      'label' => '',
      'description' => '',
      'locked_prompt' => '',
      'default_model' => 'gemini-3-pro-image-preview',
      'require_reference' => '1',
      'use_rewarded' => '1',
      'ui_language' => 'pt_BR',
      'aspect_ratio' => self::DEFAULT_ASPECT_RATIO,
      'image_size' => self::DEFAULT_IMAGE_SIZE,
      'output_mime_type' => self::DEFAULT_IMAGE_FORMAT,
      'compression_quality' => (string) self::DEFAULT_JPEG_QUALITY,
    );
  }

  /**
   * @return array<int, array<string, string>>|WP_Error
   */
  private function read_reference_images() {
    if (empty($_FILES['referenceImage']) || !is_array($_FILES['referenceImage'])) {
      return array();
    }

    $file = $_FILES['referenceImage'];
    $names = !empty($file['name']) && is_array($file['name']) ? $file['name'] : array();
    $tmp_names = !empty($file['tmp_name']) && is_array($file['tmp_name']) ? $file['tmp_name'] : array();
    $sizes = !empty($file['size']) && is_array($file['size']) ? $file['size'] : array();
    $errors = !empty($file['error']) && is_array($file['error']) ? $file['error'] : array();

    if (empty($names) && isset($file['error']) && !is_array($file['error']) && UPLOAD_ERR_NO_FILE === (int) $file['error']) {
      return array();
    }

    if (empty($names) && isset($file['tmp_name']) && !is_array($file['tmp_name'])) {
      $names = array($file['name']);
      $tmp_names = array($file['tmp_name']);
      $sizes = array($file['size']);
      $errors = array($file['error']);
    }

    $images = array();
    $total_payload_bytes = 0;

    foreach ($names as $index => $name) {
      $error_code = isset($errors[$index]) ? (int) $errors[$index] : UPLOAD_ERR_NO_FILE;

      if (UPLOAD_ERR_NO_FILE === $error_code) {
        continue;
      }

      if (UPLOAD_ERR_OK !== $error_code) {
        return new WP_Error('fcrs_upload_error', 'Falha no envio da imagem de referencia.');
      }

      $tmp_name = !empty($tmp_names[$index]) ? (string) $tmp_names[$index] : '';
      $size = !empty($sizes[$index]) ? (int) $sizes[$index] : 0;

      if (!$tmp_name || $size <= 0) {
        return new WP_Error('fcrs_upload_invalid', 'Arquivo de imagem invalido.');
      }

      if ($size > 10 * MB_IN_BYTES) {
        return new WP_Error('fcrs_upload_size', 'Cada imagem de referencia precisa ter no maximo 10 MB.');
      }

      $mime_type = function_exists('mime_content_type')
        ? mime_content_type($tmp_name)
        : '';

      if (!$mime_type || 0 !== strpos($mime_type, 'image/')) {
        return new WP_Error('fcrs_upload_type', 'Envie apenas arquivos de imagem.');
      }

      $optimized_image = $this->optimize_reference_image($tmp_name, $mime_type);

      if (is_wp_error($optimized_image)) {
        return $optimized_image;
      }

      $binary = $optimized_image['binary'];
      $payload_mime_type = $optimized_image['mimeType'];
      $base64_image = base64_encode($binary);
      $total_payload_bytes += strlen($base64_image);

      if ($total_payload_bytes > self::MAX_REFERENCE_PAYLOAD_BYTES) {
        return new WP_Error(
          'fcrs_upload_payload',
          'As imagens enviadas ficaram pesadas demais juntas. Tente usar fotos um pouco menores ou com menos resolucao.'
        );
      }

      $images[] = array(
        'imageBase64' => $base64_image,
        'mimeType' => $payload_mime_type,
      );
    }

    if (count($images) > self::MAX_REFERENCE_IMAGES) {
      return new WP_Error(
        'fcrs_upload_limit',
        'Envie no maximo ' . self::MAX_REFERENCE_IMAGES . ' imagens de referencia.'
      );
    }

    return $images;
  }

  /**
   * @param string $file_path
   * @param string $mime_type
   * @return array<string, string>|WP_Error
   */
  private function optimize_reference_image($file_path, $mime_type) {
    $editor = wp_get_image_editor($file_path);

    if (is_wp_error($editor)) {
      $binary = file_get_contents($file_path);

      if (false === $binary) {
        return new WP_Error('fcrs_upload_read', 'Nao foi possivel ler uma das imagens de referencia.');
      }

      return array(
        'binary' => $binary,
        'mimeType' => $mime_type,
      );
    }

    $size = $editor->get_size();
    $width = !empty($size['width']) ? (int) $size['width'] : 0;
    $height = !empty($size['height']) ? (int) $size['height'] : 0;
    $max_dimension = self::MAX_REFERENCE_IMAGE_DIMENSION;

    if ($width > $max_dimension || $height > $max_dimension) {
      $editor->resize($max_dimension, $max_dimension, false);
    }

    $qualities = array(82, 74, 66);

    foreach ($qualities as $quality) {
      $temp_file = wp_tempnam('fcrs-ref-');

      if (!$temp_file) {
        break;
      }

      $editor_attempt = wp_get_image_editor($file_path);

      if (is_wp_error($editor_attempt)) {
        @unlink($temp_file);
        break;
      }

      $attempt_size = $editor_attempt->get_size();
      $attempt_width = !empty($attempt_size['width']) ? (int) $attempt_size['width'] : 0;
      $attempt_height = !empty($attempt_size['height']) ? (int) $attempt_size['height'] : 0;

      if ($attempt_width > $max_dimension || $attempt_height > $max_dimension) {
        $editor_attempt->resize($max_dimension, $max_dimension, false);
      }

      $editor_attempt->set_quality($quality);
      $saved = $editor_attempt->save($temp_file, 'image/jpeg');

      if (is_wp_error($saved) || empty($saved['path']) || !file_exists($saved['path'])) {
        @unlink($temp_file);
        continue;
      }

      $optimized_binary = file_get_contents($saved['path']);
      $optimized_size = filesize($saved['path']);
      @unlink($saved['path']);

      if (false === $optimized_binary || false === $optimized_size) {
        continue;
      }

      if ($optimized_size <= self::MAX_REFERENCE_IMAGE_BYTES) {
        return array(
          'binary' => $optimized_binary,
          'mimeType' => 'image/jpeg',
        );
      }
    }

    $fallback_file = wp_tempnam('fcrs-ref-fallback-');

    if ($fallback_file) {
      $editor->set_quality(60);
      $saved = $editor->save($fallback_file, 'image/jpeg');

      if (!is_wp_error($saved) && !empty($saved['path']) && file_exists($saved['path'])) {
        $optimized_binary = file_get_contents($saved['path']);
        @unlink($saved['path']);

        if (false !== $optimized_binary) {
          return array(
            'binary' => $optimized_binary,
            'mimeType' => 'image/jpeg',
          );
        }
      }
    }

    $binary = file_get_contents($file_path);

    if (false === $binary) {
      return new WP_Error('fcrs_upload_read', 'Nao foi possivel ler uma das imagens de referencia.');
    }

    return array(
      'binary' => $binary,
      'mimeType' => $mime_type,
    );
  }

  /**
   * @param string $image_base64
   * @param string $mime_type
   * @return array<string, string>|WP_Error
   */
  private function save_preview_file($image_base64, $mime_type) {
    $binary = base64_decode($image_base64, true);

    if (false === $binary) {
      return new WP_Error('fcrs_invalid_base64', 'A imagem retornada pelo endpoint veio em base64 invalido.');
    }

    $uploads = wp_upload_dir();

    if (!empty($uploads['error'])) {
      return new WP_Error('fcrs_upload_dir', 'Nao foi possivel acessar a pasta de uploads do WordPress.');
    }

    $directory = trailingslashit($uploads['basedir']) . 'fcrs-previews/';
    $url_base = trailingslashit($uploads['baseurl']) . 'fcrs-previews/';

    if (!wp_mkdir_p($directory)) {
      return new WP_Error('fcrs_mkdir', 'Nao foi possivel criar a pasta de preview do plugin.');
    }

    $filename = wp_unique_filename(
      $directory,
      'fcrs-' . gmdate('Ymd-His') . '.' . $this->mime_to_extension($mime_type)
    );

    $file_path = $directory . $filename;
    $bytes = file_put_contents($file_path, $binary);

    if (false === $bytes) {
      return new WP_Error('fcrs_write_preview', 'Nao foi possivel salvar a imagem gerada para preview.');
    }

    return array(
      'file' => $file_path,
      'url' => $url_base . $filename,
    );
  }

  /**
   * @param string $source_path
   * @param string $mime_type
   * @return array<string, string>|WP_Error
   */
  private function save_preview_file_from_path($source_path, $mime_type) {
    if (!file_exists($source_path)) {
      return new WP_Error('fcrs_preview_source', 'O arquivo temporario do job nao existe mais.');
    }

    $uploads = wp_upload_dir();

    if (!empty($uploads['error'])) {
      return new WP_Error('fcrs_upload_dir', 'Nao foi possivel acessar a pasta de uploads do WordPress.');
    }

    $directory = trailingslashit($uploads['basedir']) . 'fcrs-previews/';
    $url_base = trailingslashit($uploads['baseurl']) . 'fcrs-previews/';

    if (!wp_mkdir_p($directory)) {
      return new WP_Error('fcrs_mkdir', 'Nao foi possivel criar a pasta de preview do plugin.');
    }

    $filename = wp_unique_filename(
      $directory,
      'fcrs-' . gmdate('Ymd-His') . '.' . $this->mime_to_extension($mime_type)
    );

    $file_path = $directory . $filename;

    if (!copy($source_path, $file_path)) {
      return new WP_Error('fcrs_copy_preview', 'Nao foi possivel copiar a imagem do job para a pasta de preview.');
    }

    return array(
      'file' => $file_path,
      'url' => $url_base . $filename,
    );
  }

  /**
   * @param string $file_path
   * @param string $file_url
   * @param string $mime_type
   * @return int|WP_Error
   */
  private function create_media_attachment($file_path, $file_url, $mime_type) {
    $attachment = array(
      'guid' => $file_url,
      'post_mime_type' => $mime_type,
      'post_title' => preg_replace('/\\.[^.]+$/', '', wp_basename($file_path)),
      'post_status' => 'inherit',
    );

    $attachment_id = wp_insert_attachment($attachment, $file_path);

    if (is_wp_error($attachment_id) || !$attachment_id) {
      return new WP_Error('fcrs_attachment', 'Nao foi possivel criar o item na biblioteca de midia.');
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';

    $metadata = wp_generate_attachment_metadata($attachment_id, $file_path);
    wp_update_attachment_metadata($attachment_id, $metadata);

    return (int) $attachment_id;
  }

  /**
   * @param string $mime_type
   * @return string
   */
  private function mime_to_extension($mime_type) {
    $map = array(
      'image/png' => 'png',
      'image/jpeg' => 'jpg',
      'image/webp' => 'webp',
      'image/gif' => 'gif',
    );

    return isset($map[$mime_type]) ? $map[$mime_type] : 'png';
  }

  /**
   * @return array<string, mixed>|null
   */
  private function get_result() {
    if (empty($_GET['fcrs_result'])) {
      return null;
    }

    $token = sanitize_text_field(wp_unslash($_GET['fcrs_result']));

    if ('' === $token) {
      return null;
    }

    $result = get_transient(self::RESULT_PREFIX . $token);

    if (!is_array($result)) {
      return null;
    }

    return $result;
  }

  /**
   * @return string
   */
  private function get_result_token() {
    if (empty($_GET['fcrs_result'])) {
      return '';
    }

    return sanitize_text_field(wp_unslash($_GET['fcrs_result']));
  }

  /**
   * @param string $token
   * @return array<string, mixed>|null
   */
  private function get_result_by_token($token) {
    if ('' === $token) {
      return null;
    }

    $result = get_transient(self::RESULT_PREFIX . $token);

    return is_array($result) ? $result : null;
  }

  /**
   * @param string $token
   * @param array<string, mixed> $result
   * @return void
   */
  private function store_result_by_token($token, array $result) {
    if ('' === $token) {
      return;
    }

    set_transient(self::RESULT_PREFIX . $token, $result, self::RESULT_TTL);
  }

  /**
   * @param string $redirect_url
   * @param array<string, mixed> $result
   * @param string $template_key
   * @param string $model
   * @param string $generation_type
   * @param int $save_to_media
   * @return void
   */
  private function redirect_with_result($redirect_url, array $result, $template_key, $model, $generation_type, $save_to_media) {
    if (isset($_POST['manualPrompt']) && !isset($result['input_prompt'])) {
      $result['input_prompt'] = sanitize_textarea_field((string) wp_unslash($_POST['manualPrompt']));
    }

    if (!isset($result['input_image_options'])) {
      $result['input_image_options'] = $this->merge_image_options(
        array(),
        $this->sanitize_image_options($_POST, 'fcrs_test_', false)
      );
    }

    $token = wp_generate_password(20, false, false);
    $this->store_result_by_token($token, $result);

    $redirect_url = add_query_arg(
      array(
        'fcrs_result' => $token,
        'fcrs_template' => $template_key,
        'fcrs_model' => $model,
        'fcrs_generation_type' => $generation_type,
        'fcrs_save_media' => $save_to_media ? '1' : '0',
      ),
      $redirect_url
    );

    wp_safe_redirect($redirect_url);
    exit;
  }

  /**
   * @return string
   */
  private function get_redirect_url() {
    $fallback = home_url('/');
    $requested = isset($_POST['redirect_to'])
      ? wp_unslash($_POST['redirect_to'])
      : '';

    if (!$requested) {
      $requested = wp_get_referer();
    }

    if (!$requested) {
      return $fallback;
    }

    return wp_validate_redirect($requested, $fallback);
  }

  /**
   * @return string
   */
  private function get_current_url() {
    $fallback = home_url('/');
    $request_uri = isset($_SERVER['REQUEST_URI'])
      ? wp_unslash($_SERVER['REQUEST_URI'])
      : '';

    if (!$request_uri) {
      return $fallback;
    }

    return home_url($request_uri);
  }

  private function enqueue_assets() {
    wp_enqueue_style(
      'fcrs-front-v3',
      FCRS_PLUGIN_URL . 'assets/fcrs-front-v3.css',
      array(),
      '1.8.11'
    );
    wp_enqueue_script(
      'fcrs-ui-v3',
      FCRS_PLUGIN_URL . 'assets/fcrs-ui-v3.js',
      array(),
      '1.8.11',
      true
    );
    wp_localize_script(
      'fcrs-ui-v3',
      'FCRSUi',
      array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'statusAction' => self::JOB_STATUS_ACTION,
        'statusNonce' => wp_create_nonce(self::STATUS_NONCE),
        'pollInitialDelayMs' => 1500,
        'pollScheduleMs' => array(6000, 10000, 15000, 20000),
        'pollHiddenTabMs' => 30000,
        'pollErrorDelayMs' => 15000,
        'maxReferenceImages' => self::MAX_REFERENCE_IMAGES,
        'loadingMessages' => array(
          'Estamos gerando a sua imagem com muito carinho.',
          'Organizando luz, enquadramento e detalhes finais.',
          'Escolhendo os melhores detalhes para deixar tudo ainda mais bonito.',
          'Preparando um resultado caprichado para aparecer aqui.',
          'Ajustando cores, contraste e expressão com bastante cuidado.',
          'Quase lá: sua imagem está recebendo os últimos retoques.',
          'Dando um toque especial para a sua imagem ficar ainda mais incrível.',
          'Refinando cada detalhe para entregar um resultado bem bonito.',
        ),
      )
    );
  }

  /**
   * @param string $template_key
   * @param string $model_override
   * @param array<string, string> $args
   * @return string
   */
  private function render_generator_panel($template_key, $model_override, array $args) {
    $template = $this->get_template($template_key);

    if (!$template) {
      return '';
    }

    $this->enqueue_assets();

    $result = $this->get_result();
    $result_token = $this->get_result_token();
    $config = $this->get_config();
    $action_url = esc_url(admin_url('admin-post.php'));
    $redirect_to = esc_url($this->get_current_url());
    $title = !empty($args['title']) ? (string) $args['title'] : 'Gerador de imagem';
    $submit_label = !empty($args['submit_label']) ? (string) $args['submit_label'] : 'Gerar imagem';
    $button_disabled = !$config['ready'];
    $model_in_use = $model_override
      ? $model_override
      : $template['default_model'];
    $template_requires_reference = !empty($template['require_reference']);
    $template_use_rewarded = !empty($template['use_rewarded']);
    $template_ui_language = !empty($template['ui_language'])
      ? $this->normalize_interface_language((string) $template['ui_language'])
      : 'pt_BR';
    $ui_strings = $this->get_interface_strings($template_ui_language);
    $generator_description = !empty($args['description']) ? (string) $args['description'] : (string) $ui_strings['tip'];
    $max_reference_images = self::MAX_REFERENCE_IMAGES;
    $article_config = array(
      'template_key' => $template_key,
    );

    ob_start();
    include FCRS_PLUGIN_DIR . 'templates/article-generator-v3.php';
    return (string) ob_get_clean();
  }

  /**
   * @param string $candidate
   * @param array<string, array<string, mixed>> $templates
   * @param string $current_key
   * @return string
   */
  private function get_unique_template_key($candidate, array $templates, $current_key = '') {
    $base_key = sanitize_key($candidate);

    if ('' === $base_key) {
      $base_key = 'template';
    }

    if ('' !== $current_key && $current_key === $base_key) {
      return $base_key;
    }

    $key = $base_key;
    $suffix = 2;

    while (isset($templates[$key]) && $key !== $current_key) {
      $key = $base_key . '_' . $suffix;
      $suffix++;
    }

    return $key;
  }

  /**
   * @param string $template_key
   * @return int
   */
  private function count_template_usage($template_key) {
    global $wpdb;

    $query = new WP_Query(
      array(
        'post_type' => array('post', 'page'),
        'post_status' => 'any',
        'posts_per_page' => 1,
        'fields' => 'ids',
        'meta_key' => self::POST_META_TEMPLATE,
        'meta_value' => $template_key,
        'no_found_rows' => false,
      )
    );

    $meta_count = (int) $query->found_posts;
    $block_signature = '"templateKey":"' . $template_key . '"';
    $block_count = (int) $wpdb->get_var(
      $wpdb->prepare(
        "SELECT COUNT(ID)
         FROM {$wpdb->posts}
         WHERE post_type IN ('post', 'page')
           AND post_status NOT IN ('auto-draft', 'trash')
           AND post_content LIKE %s",
        '%' . $wpdb->esc_like($block_signature) . '%'
      )
    );

    return $meta_count + $block_count;
  }

  /**
   * @param array<string, string> $args
   * @return void
   */
  private function redirect_admin_page(array $args = array()) {
    wp_safe_redirect(add_query_arg($args, admin_url('tools.php?page=' . self::PAGE_SLUG)));
    exit;
  }

  /**
   * @param string $endpoint
   * @param string $path
   * @return string
   */
  private function build_endpoint_url($endpoint, $path = '') {
    $base = rtrim((string) $endpoint, '/');
    $suffix = $path ? '/' . ltrim((string) $path, '/') : '';

    return $base . $suffix;
  }

  /**
   * @param array<string, mixed> $config
   * @param string $job_id
   * @param array<string, mixed> $status_data
   * @param array<string, mixed> $current_result
   * @return array<string, mixed>|WP_Error
   */
  private function resolve_completed_job_result(array $config, $job_id, array $status_data, array $current_result) {
    $mime_type = !empty($status_data['mimeType'])
      ? (string) $status_data['mimeType']
      : 'image/png';
    $remote_result_url = !empty($status_data['resultUrl'])
      ? esc_url_raw((string) $status_data['resultUrl'])
      : '';

    if ($remote_result_url && empty($current_result['save_to_media'])) {
      $resolved_result = $current_result;
      $resolved_result['status'] = 'success';
      $resolved_result['message'] = 'Imagem gerada com sucesso.';
      $resolved_result['preview_url'] = $remote_result_url;
      $resolved_result['download_url'] = $remote_result_url;
      $resolved_result['mime_type'] = $mime_type;
      $resolved_result['text'] = !empty($status_data['text'])
        ? wp_strip_all_tags((string) $status_data['text'])
        : '';
      $resolved_result['remote_result'] = 1;
      $resolved_result['temporary_result'] = !empty($status_data['temporaryResult']) ? 1 : 0;
      $resolved_result['result_url_expires_at'] = !empty($status_data['resultUrlExpiresAt'])
        ? (string) $status_data['resultUrlExpiresAt']
        : '';

      return $resolved_result;
    }

    $temp_file = wp_tempnam('fcrs-job-' . $job_id);

    if (!$temp_file) {
      return new WP_Error('fcrs_temp_file', 'Nao foi possivel preparar um arquivo temporario para baixar o resultado.');
    }

    $download_response = wp_remote_get(
      $this->build_endpoint_url($config['endpoint'], '/jobs/' . rawurlencode($job_id) . '/result'),
      array(
        'timeout' => max(60, $config['timeout']),
        'headers' => array(
          'X-Site-Secret' => $config['secret'],
        ),
        'stream' => true,
        'filename' => $temp_file,
      )
    );

    if (is_wp_error($download_response)) {
      @unlink($temp_file);
      return new WP_Error('fcrs_download_job', 'Falha ao baixar o resultado do job: ' . $download_response->get_error_message());
    }

    $status_code = (int) wp_remote_retrieve_response_code($download_response);

    if ($status_code < 200 || $status_code >= 300) {
      @unlink($temp_file);
      return new WP_Error('fcrs_download_job_status', 'O endpoint nao devolveu o arquivo final do job.');
    }

    $mime_type = !empty($status_data['mimeType'])
      ? (string) $status_data['mimeType']
      : (string) wp_remote_retrieve_header($download_response, 'content-type');

    $preview = $this->save_preview_file_from_path($temp_file, $mime_type);
    @unlink($temp_file);

    if (is_wp_error($preview)) {
      return $preview;
    }

    $resolved_result = $current_result;
    $resolved_result['status'] = 'success';
    $resolved_result['message'] = 'Imagem gerada com sucesso.';
    $resolved_result['preview_url'] = $preview['url'];
    $resolved_result['download_url'] = $preview['url'];
    $resolved_result['mime_type'] = $mime_type;
    $resolved_result['text'] = !empty($status_data['text'])
      ? wp_strip_all_tags((string) $status_data['text'])
      : '';
    $resolved_result['remote_result'] = 0;
    $resolved_result['temporary_result'] = !empty($status_data['temporaryResult']) ? 1 : 0;
    $resolved_result['result_url_expires_at'] = !empty($status_data['resultUrlExpiresAt'])
      ? (string) $status_data['resultUrlExpiresAt']
      : '';

    if (!empty($resolved_result['save_to_media'])) {
      $attachment_id = $this->create_media_attachment($preview['file'], $preview['url'], $mime_type);

      if (is_wp_error($attachment_id)) {
        $resolved_result['status'] = 'warning';
        $resolved_result['message'] = 'A imagem foi gerada, mas nao foi possivel salvar na biblioteca de midia.';
        $resolved_result['text'] = trim($resolved_result['text'] . ' ' . $attachment_id->get_error_message());
      } else {
        $resolved_result['attachment_id'] = $attachment_id;
      }
    }

    return $resolved_result;
  }

  /**
   * @param array<string, mixed> $source
   * @param string $prefix
   * @param bool $with_defaults
   * @return array<string, mixed>
   */
  private function sanitize_image_options(array $source, $prefix = '', $with_defaults = true) {
    $aspect_ratio_options = $this->get_aspect_ratio_options();
    $image_size_options = $this->get_image_size_options();
    $format_options = $this->get_format_options();
    $aspect_ratio_key = $prefix ? $prefix . 'aspect_ratio' : 'aspectRatio';
    $image_size_key = $prefix ? $prefix . 'image_size' : 'imageSize';
    $output_mime_key = $prefix ? $prefix . 'output_mime_type' : 'outputMimeType';
    $compression_key = $prefix ? $prefix . 'compression_quality' : 'compressionQuality';
    $options = array();

    if (isset($source[$aspect_ratio_key])) {
      $aspect_ratio = sanitize_text_field((string) wp_unslash($source[$aspect_ratio_key]));

      if (isset($aspect_ratio_options[$aspect_ratio])) {
        $options['aspectRatio'] = $aspect_ratio;
      }
    }

    if (isset($source[$image_size_key])) {
      $image_size = strtoupper(sanitize_text_field((string) wp_unslash($source[$image_size_key])));

      if (isset($image_size_options[$image_size])) {
        $options['imageSize'] = $image_size;
      }
    }

    if (isset($source[$output_mime_key])) {
      $output_mime_type = sanitize_text_field((string) wp_unslash($source[$output_mime_key]));

      if (isset($format_options[$output_mime_type])) {
        $options['outputMimeType'] = $output_mime_type;
      }
    }

    if (isset($source[$compression_key])) {
      $options['compressionQuality'] = min(100, max(0, (int) wp_unslash($source[$compression_key])));
    }

    if (!$with_defaults) {
      return $options;
    }

    return array(
      'aspectRatio' => !empty($options['aspectRatio']) ? $options['aspectRatio'] : self::DEFAULT_ASPECT_RATIO,
      'imageSize' => !empty($options['imageSize']) ? $options['imageSize'] : self::DEFAULT_IMAGE_SIZE,
      'outputMimeType' => !empty($options['outputMimeType']) ? $options['outputMimeType'] : self::DEFAULT_IMAGE_FORMAT,
      'compressionQuality' => isset($options['compressionQuality']) ? $options['compressionQuality'] : self::DEFAULT_JPEG_QUALITY,
    );
  }

  /**
   * @param array<string, mixed> $template
   * @return array<string, mixed>
   */
  private function extract_template_image_options(array $template) {
    if (empty($template['image_options']) || !is_array($template['image_options'])) {
      return $this->get_default_image_options();
    }

    return $this->sanitize_image_options($template['image_options'], '', true);
  }

  /**
   * @param array<string, mixed> $base
   * @param array<string, mixed> $override
   * @return array<string, mixed>
   */
  private function merge_image_options(array $base, array $override) {
    return $this->sanitize_image_options(array_merge($base, $override), '', true);
  }

  /**
   * @return array<string, mixed>
   */
  private function get_default_image_options() {
    return array(
      'aspectRatio' => self::DEFAULT_ASPECT_RATIO,
      'imageSize' => self::DEFAULT_IMAGE_SIZE,
      'outputMimeType' => self::DEFAULT_IMAGE_FORMAT,
      'compressionQuality' => self::DEFAULT_JPEG_QUALITY,
    );
  }
}
